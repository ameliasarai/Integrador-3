
package Modelo;


public class Encuesta {
 private final String pregunta1;
 private final String pregunta2;
 private final String pregunta3;
 
 public Encuesta(){
     pregunta1 = "1. El docente explica claramente?";
     pregunta2 = "2. El docente responde dudas?";
     pregunta3 = "3. El docente es puntual?";
 }

    public String getPregunta1() {
        return pregunta1;
    }

    public String getPregunta2() {
        return pregunta2;
    }

    public String getPregunta3() {
        return pregunta3;
    }
 
}
