
package Modelo;

import java.util.ArrayList;

public class DAOEncuesta {
Encuesta encuesta = new Encuesta ();
ArrayList<respuestaEncuesta> respuestas = new ArrayList<>();
public Encuesta obtenerEncuesta(){
    return encuesta;
}
public void guardarRes (respuestaEncuesta respuesta){
    respuestas.add(respuesta);
}
public void mostrarRes (){
    if (respuestas.isEmpty()){
        System.out.println("----No hay respuestas----");
    }else{
        for (respuestaEncuesta respuesta : respuestas){
            System.out.println("-------------------------");
            System.out.println(respuesta);
        }
    }
}
}
