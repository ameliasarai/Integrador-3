
package Modelo;


public class Estudiante {
 private int carnet;
 private String nombre;
 private String carrera;

    public Estudiante(int carnet, String nombre, String carrera) {
        this.carnet = carnet;
        this.nombre = nombre;
        this.carrera = carrera;
    }

    public int getCarnet() {return carnet;}

    public void setCarnet(int carnet) {this.carnet = carnet;}

    public String getNombre() {return nombre;}

    public void setNombre(String nombre) {this.nombre = nombre;}

    public String getCarrera() {return carrera;}

    public void setCarrera(String carrera) {this.carrera = carrera;}

    @Override
    public String toString() {
        return "carnet:" + carnet +
       "\nNombre:" + nombre + 
        "\nCarrera" + carrera;
    }
  
    
}
