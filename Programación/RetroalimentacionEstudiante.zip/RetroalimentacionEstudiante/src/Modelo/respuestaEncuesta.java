
package Modelo;

public class respuestaEncuesta {
private final String respuesta1;
private final String respuesta2;
private final String respuesta3;

    public respuestaEncuesta(String respuesta1, String respuesta2, String respuesta3) {
        this.respuesta1 = respuesta1;
        this.respuesta2 = respuesta2;
        this.respuesta3 = respuesta3;
    }

    @Override
    public String toString() {
        return "Respuesta 1 :" + respuesta1 + 
                "\nRespuesta 2:" + respuesta2 +
                "\nRespuesta 3:" + respuesta3;
        
    }
}
