
package Modelo;

import java.util.ArrayList;

public class DAOEstudiante {
 private final ArrayList<Estudiante> listaEstudiante;

    public DAOEstudiante() {
        this.listaEstudiante = new ArrayList<>();
    }
    public void agregarEs (Estudiante estudiante){
        listaEstudiante.add(estudiante);
    }
    public void mostrarEs(){
        if(listaEstudiante.isEmpty()){
             System.out.println("----No hay estudiantes registrados----");
        }else{
            
            for (Estudiante estudiante : listaEstudiante){
                System.out.println("-------------------------------");
                System.out.println(estudiante);
            }
        }
           
    }
}
