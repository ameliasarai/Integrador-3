
package Modelo;

import java.util.ArrayList;

public class DAOForo {
ArrayList <Foro> listaForos = new ArrayList<>();

public void agregarForo (Foro foro){
    listaForos.add(foro);
   
}
public void mostrarForos(){
    if (listaForos.isEmpty()){
        System.out.println("----No hay temas en el foro----");
    }else{
        for (Foro foro : listaForos){
            System.out.println("-------------");
            System.out.println(foro);
        }
    }
}
}
