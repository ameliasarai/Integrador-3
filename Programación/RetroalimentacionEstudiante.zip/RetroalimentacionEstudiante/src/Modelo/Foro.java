
package Modelo;

public class Foro {
private final String tema;
private final String comentario;

    public Foro(String tema, String comentario) {
        this.tema = tema;
        this.comentario = comentario;
    }

    @Override
    public String toString() {
        return "Tema:" + tema + 
                "\nComentario:" + comentario;
    }


}
