
package Controlador;
import Modelo.DAOEstudiante;
import Modelo.Estudiante;

public class estudianteController {
    DAOEstudiante dao = new DAOEstudiante ();
    public void agregarEs (int carnet, String nombre, String carrera){
        Estudiante estudiante = new Estudiante (carnet, nombre, carrera);
        
        dao.agregarEs(estudiante);
        System.out.println("----Agregado correctamente----");
    }
    public void mostrarEs(){
        dao.mostrarEs();
    }
}
