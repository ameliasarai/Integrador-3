
package Controlador;

import Modelo.DAOEncuesta;
import Modelo.Encuesta;
import Modelo.respuestaEncuesta;

public class EncuestaController {
    
    DAOEncuesta dao = new DAOEncuesta();
    
    public Encuesta obtenerEncuesta (){
        return dao.obtenerEncuesta();
    }
    public void responderEncuesta(String r1,String r2,String r3){
        respuestaEncuesta respuesta = new respuestaEncuesta (r1,r2,r3);
        dao.guardarRes(respuesta);
        System.out.println("----Encuesta respondida----");
    }
    public void mostrarRes(){
        dao.mostrarRes();
  }
}