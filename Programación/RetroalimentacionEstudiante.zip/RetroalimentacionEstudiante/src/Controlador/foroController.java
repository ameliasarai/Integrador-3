
package Controlador;

import Modelo.DAOForo;
import Modelo.Foro;

public class foroController {
    DAOForo dao = new DAOForo ();
    
    public void crearForo (String tema, String comentario){
      Foro foro = new Foro (tema, comentario);
      dao.agregarForo(foro);
        System.out.println("----Tema agregado----");
    }
    public void mostrarForos(){
        dao.mostrarForos();
    }
}
