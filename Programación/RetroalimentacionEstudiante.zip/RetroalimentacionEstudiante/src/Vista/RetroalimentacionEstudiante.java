
package Vista;

import Controlador.estudianteController;
import Controlador.EncuestaController;
import Controlador.foroController;
import Modelo.Encuesta;

import java.util.Scanner;

public class RetroalimentacionEstudiante {
    public static void main(String[] args) {
      Scanner leer = new Scanner(System.in);
      
      estudianteController estudianteController = new estudianteController();
      EncuestaController encuestaController = new EncuestaController();
      foroController foroController = new foroController ();
      
      int opcion;
      
      do{
          System.out.println("\n=====SISTEMA DE RETROALIMENTACION=====");
          System.out.println("1.Ingresar sus datos");
          System.out.println("2.Mostrar datos");
          System.out.println("3.Responder encuesta");
          System.out.println("4. Mostrar respuestas");
          System.out.println("5. Crear foro");
          System.out.println("6. Mostrar");
          System.out.println("7.Salir");
          
          System.out.print("Seleccione una opcion:");
          opcion = leer.nextInt();
          leer.nextLine();
          
          switch (opcion){
               
              case 1 -> { 
                  System.out.print("Carnet:");
                  int carnet = leer.nextInt();
                  leer.nextLine();
                  
                  System.out.print("Nombre:");
                  String nombre = leer.nextLine();
                  
                  System.out.println("Carrera:");
                  String carrera = leer.nextLine();
                  
                  estudianteController.agregarEs(carnet, nombre, carrera);
                  break;
              }
                  
              case 2 -> {
        System.out.print("---- LISTA DE ESTUDIANTES----");
                  estudianteController.mostrarEs(); 
              }
                  
              case 3 -> {
                  Encuesta encuesta = encuestaController.obtenerEncuesta();
                  System.out.println(encuesta.getPregunta1());
                  String r1 = leer.nextLine();
                  
                  System.out.println(encuesta.getPregunta2());
                  String r2 = leer.nextLine();
                  
                  System.out.println(encuesta.getPregunta3());
                  String r3 = leer.nextLine();
                  
                  encuestaController.responderEncuesta(r1, r2, r3);
                  break;
              }
                  
              case 4 ->{
                   System.out.print("----LISTA DE RESPUESTAS DE LA ENCUESTA----");
                  encuestaController.mostrarRes();
              }
              case 5 -> {
                  System.out.print("----Tema del foro:----");
                  String tema = leer.nextLine();
                  
                  System.out.print("Comentario:");
                  String comentario = leer.nextLine();
                  
                  foroController.crearForo(tema, comentario);
                  break;
              }
                  
              case 6 ->{
                   System.out.print("----FORO----");
                  foroController.mostrarForos();
              }
              case 7 -> System.out.println("Saliendoooooooooo :P");
                  
          }
       } while(opcion != 7);
  }
}
